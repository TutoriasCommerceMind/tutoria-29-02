import { Component } from '@angular/core';

@Component({
  selector: 'app-lista',
  templateUrl: './lista.component.html',
  styleUrl: './lista.component.css',
})
export class ListaComponent {
  images = true;
  search = '';
  listaDeHeroes = [
    {
      name: 'superman',
      image:
        'https://i.pinimg.com/736x/51/36/f0/5136f0ddd8ec0bd4ffe64e0d65134cb7.jpg',
      power: '100',
    },
    {
      name: 'spiderman',
      image:
        'https://i.pinimg.com/550x/7f/dc/ff/7fdcff5a6fda8eaf7656f3c5e9084d7f.jpg',
      power: '80',
    },
    {
      name: 'batman',
      image:
        'https://img.stablecog.com/insecure/256w/aHR0cHM6Ly9iLnN0YWJsZWNvZy5jb20vYmZhYmFjYTgtNjZkZS00MzQ5LWFkMDYtNzYyMzAwZDQ2OGIwLmpwZWc.webp',
      power: '50',
    },
  ];

  listaFiltrada = this.listaDeHeroes;

  toggleImages() {
    this.images = !this.images;
  }

  searchHeroes() {
    this.listaFiltrada = this.listaDeHeroes.filter((heroe) =>
      heroe.name.toLowerCase().includes(this.search.toLowerCase())
    );
  }
}
